import Cocoa

func sqrt (_ number:Double, tizedesjegy eddig:Int = 3) -> Double
{
    var sqrt1: String = ""
    var sqrt_tomb = [String]()
    for index in 0...Int(number)
    {
        let negyzet = index * index
        if number < Double(negyzet)
        {
            sqrt_tomb.append(String(index-1))
            sqrt_tomb.append(".")
            var szamlalo: Int = 0
            
            repeat
            {
                loop: for index1 in 0...9
                {
                    var sqrt_copy: String = ""
                    for index in sqrt_tomb
                    {
                        sqrt_copy += index
                    }
                    sqrt_copy += String(index1)
                    var negyzet1: Double = 0
                    let negyzet_proba = Double(sqrt_copy) ?? 0
                    negyzet1 = negyzet_proba * negyzet_proba
                    if number < negyzet1
                    {
                        sqrt_tomb.append(String(index1-1))
                        break loop
                    } else if index1 == 9
                    {
                        sqrt_tomb.append(String(index1))
                        break loop
                    }
                }
                szamlalo += 1
            } while szamlalo <= eddig
            
            if Int(sqrt_tomb[sqrt_tomb.count-1])! >= 5
            {
                sqrt_tomb.remove(at: sqrt_tomb.count-1)
                let adott_elem = Int(sqrt_tomb[sqrt_tomb.count-1])! + 1
                sqrt_tomb.remove(at: sqrt_tomb.count-1)
                sqrt_tomb.append(String(adott_elem))
            } else {
                sqrt_tomb.remove(at: sqrt_tomb.count-1)
            }
            break
        }
    }
    for index in sqrt_tomb {
        sqrt1 += index
    }
return Double(sqrt1)!
}

let szam: Double = 1234
print(sqrt(szam, tizedesjegy: 31))


